@extends('layouts.master')
@section('title')
    Starter Page
@endsection
@section('page-title')
    Starter Page
@endsection
 
    @section('content')
    <!-- start content here -->
     
    @endsection
    @section('scripts')
        <!-- App js -->
        <script src="{{ URL::asset('build/js/app.js') }}"></script>
    @endsection
