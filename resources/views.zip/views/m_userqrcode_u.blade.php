<div class="bg-white p-2"> 

 {!! QrCode::size(250)->generate('18399124'); !!}

</div>