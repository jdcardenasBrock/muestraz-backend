<?php

namespace App\Livewire\Quiz;

use Livewire\Component;

class QuizModal extends Component
{
    public function render()
    {
        return view('livewire.quiz.quiz-modal');
    }
}
