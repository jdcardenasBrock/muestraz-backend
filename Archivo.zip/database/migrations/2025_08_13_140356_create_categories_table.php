<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('image_path'); // Ruta de la imagen
            $table->integer('order')->default(0); // Orden en el carrusel
            $table->boolean('active')->default(true); // Estado
            $table->enum('target', ['_self', '_blank'])->default('_self'); // Redirección interna o nueva pestaña
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};